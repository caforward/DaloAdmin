#coding:utf-8
"""
1.角色按a射出子弹，2.子弹边界清除，3.角色按空格跳
"""
import pygame
from pygame.locals import *
import time
import random
import sys
import os
#初始化pygame环境
pygame.init ()

#创建一个长宽分别为1300/700窗口
os.environ[ 'SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (0, 25)
canvas = pygame.display.set_mode((1290,715))
canvas.fill((255,255,255))

#设置窗口标题
pygame.display.set_caption("赛车")
#图片素材
sh = pygame.image.load("images/子弹.png")
bg = [pygame.image.load("images/bg01.jpg"),
      pygame.image.load("images/bg11.jpg"),
      pygame.image.load("images/bg12.jpg"),
      pygame.image.load("images/bg3.jpg")]
run = []
#添加图片
add = 1
def run_add():
    global run,add
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    if add>=6:
        add = 1
    add += 1


def handleEvent():  
    for event in pygame.event.get():
        if event.type == QUIT :
            pygame.quit() 
            sys.exit()
        if event.type  == KEYDOWN and event.key == K_x:
            Game.hero.shoot()
        if event.type == KEYDOWN and event.key == K_SPACE:
            Game.hero.jump()
        
# 工具方法-写文字方法
def fillText(text, position, view=canvas):
    # 设置字体样式和大小
    my_font = pygame.font.SysFont("微软雅黑",100)
    # 渲染文字
    text = my_font.render(text, True, (0, 0, 0))
    view.blit(text, position)
CLOCK = pygame.time.Clock()


#创建hero类
class Hero():
    def __init__(self):
        self.x = 100
        self.y = 200
        self.r = 0
        self.biao = 1
        #跳的速度
        self.a = 1
        self.y_min = self.y - 200
        self.y_max = self.y
    #画
    def paint(self):
        canvas.blit(run[self.r],(self.x,self.y))
    #跳
    def jump(self):
        self.y -= self.a
        if self.y < self.y_min:
            self.a = -1
        if self.y > self.y_max:
            self.a = 0
    def shoot(self):
        Game.bullets.append(Bullet(self.x+100,self.y+28,sh))
    #角色行走 函数
    def run_hero(self,sky):
        #获取键盘事件
        a = pygame.key.get_pressed()
        if a[K_RIGHT]:
            self.x += 3
            #轮换图片
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_LEFT]:
            self.x -= 3
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_UP]:
            self.y -= 1
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_DOWN]:
            self.y += 1
            if self.r>=16:
                self.r = 0
            self.r += 1
        #移动范围
        if self.x >1290/3:
            if sky.x>-1290/2:#背景小于 -1290/2 背景停止移动，角色边界消除
                sky.move()#坐标移到中间，背景移动
                self.x = 1290/3
        #当角色右边出窗，角色坐标x=0,换背景图片,初始化两张背景坐标
        if self.x>1290:
            self.x = 0
            sky.img = bg[self.biao]
            sky.x = 0
            sky.x1 = 1290
            self.biao += 1 
        if self.x <0:#碰右边出不去
            self.x = 0 
            
        #不同背景 不同界限
#         print(self.y)用于提取y坐标
        #第二个背景    153--419
        if self.biao == 2:
            if self.y >419:
                self.y = 419
            if self.y <153:
                self.y = 153
        #第三个背景  189--261
        elif self.biao == 3:
            if self.y >261:
                self.y = 261
            if self.y <189:
                self.y = 189        
        #第一个背景y的界限    300<y<=480
        else:
            if self.y >480:
                self.y = 480
            if self.y <300:
                self.y = 300
#背景类
class Sky():
    def __init__(self):
        self.x = 0
        self.y = 0
        self.x1 = 1290
        self.y1 = 0
        self.img = bg[0]
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
#         canvas.blit(self.img,(self.x1,self.y1))
    def move(self):
        self.x -= 3
        self.x1 -=3
        if self.x <-1290:
            self.x = 1290
        if self.x1 <-1290:
            self.x1 = 1290
#子弹类
class Bullet():
    def __init__(self,x,y,img):
        self.x = x
        self.y = y
        self.img = img
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
    def move(self):
        self.x = self.x + 10  
#子弹越界删除
def out_right():
    for b in Game.bullets:
        if b.x >1000:
            Game.bullets.remove(b)
#类属性          
class Game():
    bullets = []
    hero = Hero()            
    state = 'RUN'        
    sky = Sky() 
  
while True:
    #在运行流程中
    if Game.state == "RUN":
        #英雄移动
        run_add()
        #画背景，画英雄
        Game.sky.paint()
        Game.hero.paint()
        Game.hero.run_hero(Game.sky)
        #子弹
        for b in Game.bullets:
            b.paint()
            b.move()
    #出界子弹清理
    out_right()
    # 监听有没有按下退出按钮
    handleEvent()
    # 更新屏幕内容
    pygame.display.update()
    #延时10毫秒 
#     CLOCK.tick(10)

"""
#登录界面
#添加技能   




"""

