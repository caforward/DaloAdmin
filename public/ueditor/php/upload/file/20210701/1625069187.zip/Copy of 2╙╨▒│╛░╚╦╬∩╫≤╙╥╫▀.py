#coding:utf-8
import pygame
from pygame.locals import *
import time
import random
import sys
import os
#初始化pygame环境
pygame.init ()

#创建一个长宽分别为1300/700窗口
os.environ[ 'SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (0, 25)
canvas = pygame.display.set_mode((1290,715))
canvas.fill((255,255,255))

#设置窗口标题
pygame.display.set_caption("赛车")
#图片素材
bg = [pygame.image.load("images/bg.jpg"),
      pygame.image.load("images/bg1.jpg"),
      pygame.image.load("images/bg2.jpg"),
      pygame.image.load("images/bg3.jpg")]
run = []
#添加图片
add = 1
def run_add():
    global run,add
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    run.append(pygame.image.load("images/run"+str(add)+".png"))
    if add>=6:
        add = 1
    add += 1


def handleEvent():  
    for event in pygame.event.get():
        if event.type == QUIT :
            pygame.quit() 
            sys.exit()
        
# 工具方法-写文字方法
def fillText(text, position, view=canvas):
    # 设置字体样式和大小
    my_font = pygame.font.SysFont("微软雅黑",100)
    # 渲染文字
    text = my_font.render(text, True, (0, 0, 0))
    view.blit(text, position)
CLOCK = pygame.time.Clock()
r = 0
x = 100
y = 400


class Hero():
    def __init__(self):
        self.x = 100
        self.y = 400
        self.r = 0
    def paint(self):
        canvas.blit(run[self.r],(self.x,self.y))
    #角色行走 函数
    def run_hero(self):
        #获取键盘事件
        a = pygame.key.get_pressed()
        if a[K_RIGHT]:
            self.x += 3
            #轮换图片
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_LEFT]:
            self.x -= 3
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_UP]:
            self.y -= 1
            if self.r>=16:
                self.r = 0
            self.r += 1
        if a[K_DOWN]:
            self.y += 1
            if self.r>=16:
                self.r = 0
            self.r += 1
hero = Hero()
while True:
    run_add()
    canvas.fill((255,255,255))
    hero.paint()
    hero.run_hero()
    # 监听有没有按下退出按钮
    handleEvent()
    # 更新屏幕内容
    pygame.display.update()
    #延时10毫秒 
#     CLOCK.tick(10)



