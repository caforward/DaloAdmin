#coding:utf-8
import pygame
from pygame.locals import *
import time
import random
import sys
import os
#初始化pygame环境
pygame.init ()

#创建一个长宽分别为1300/700窗口
os.environ[ 'SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (0, 25)
canvas = pygame.display.set_mode((1000,600))
canvas.fill((255,255,255))

#设置窗口标题
pygame.display.set_caption("赛车")
run = [pygame.image.load("images/run1.png"),
       pygame.image.load("images/run2.png"),
       pygame.image.load("images/run3.png"),
       pygame.image.load("images/run4.png"),
       pygame.image.load("images/run5.png"),
       pygame.image.load("images/run6.png")]

def handleEvent():  
    for event in pygame.event.get():
        if event.type == QUIT :
            pygame.quit() 
            sys.exit()
        
# 工具方法-写文字方法
def fillText(text, position, view=canvas):
    # 设置字体样式和大小
    my_font = pygame.font.SysFont("微软雅黑",100)
    # 渲染文字
    text = my_font.render(text, True, (0, 0, 0))
    view.blit(text, position)
CLOCK = pygame.time.Clock()
r = 0
x = 100



while True:
    canvas.fill((255,255,255))
    
    a = pygame.key.get_pressed()
    if a[K_RIGHT]:
        x += 20
        if r>=5:
            r = 0
        r += 1
    if a[K_LEFT]:
        x -= 20
        if r>=5:
            r = 0
        r += 1
    canvas.blit(run[r],(x,300))
    # 监听有没有按下退出按钮
    handleEvent()
    # 更新屏幕内容
    pygame.display.update()
    #延时10毫秒 
    CLOCK.tick(10)



