#设置画布加载图片
import pygame
from pygame.locals import *
import time
import random
import sys
#初始化pygame环境
pygame.init()
#设置画布
canvas = pygame.display.set_mode((990,600))
canvas.fill((255,255,255))
pygame.display.set_caption("射击")
#加载图片
bg = pygame.image.load("images/蓝色背景.png")
#弓箭
s1 = pygame.image.load("images/s1.png")
s2 = pygame.image.load("images/s2.png")
s3 = pygame.image.load("images/s3.png")

#气球 
q1 = pygame.image.load("images/red.png")
q2 = pygame.image.load("images/green.png")
q3 = pygame.image.load("images/yellow.png")
q4 = pygame.image.load("images/灰.png")
#事件
def handleEvent():
    for event in pygame.event.get():
        if event.type == QUIT :
            pygame.quit() 
            sys.exit()
        if event.type == MOUSEMOTION: #鼠标控制英雄
            if Game.state[0]=="RUN":
                Game.hero.y = event.pos[1] - Game.hero.height/2
        if event.type == KEYDOWN and event.key == K_SPACE:  #按下空格
            if Game.hero.img == s2:   #s2切换s1
                Game.hero.img = s1
                
                
                Game.hero.shoot()
        if event.type == KEYUP and event.key == K_SPACE:#抬起空格
            if Game.hero.img == s1:   #s1切换s2
                Game.hero.img = s2 
#添加时间间隔的方法
def isActionTime(lastTime, interval):
    if lastTime == 0:
        return True
    currentTime = time.time()
    return currentTime - lastTime >= interval                 
#hero类
class Hero():
    def __init__(self,x,y,img):
        self.width=60        
        self.height=59
        self.x=x
        self.y=y
        self.img=img
        
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
    def shoot(self):
        #修改  ：把x，y换成参数换了
        Game.bullt.append(Bullt(56,self.y+25,s3))
        #if Game.score>=10:
            #Game.bullt.append(Bullt(56,self.y+40,s3))
            #Game.bullt.append(Bullt(56,self.y+10,s3))
#子弹类
class Bullt():
    def __init__(self,x,y,img):
        self.width=60        
        self.height=59
        self.x=x
        self.y=y
        self.img=img
        #额外的添加的属性
        self.life = 1
        self.a = random.randint(1,10)
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
    def step(self):
        
            self.x += self.a 
#敌人类
class Enemy():
    def __init__(self,x,y,img):
        self.x = x
        self.y = y
        self.a = 0
        self.img = img
        #额外添加的属性
        self.width = 10
        self.height = 70
        self.life = 1
        self.score = 1
        self.a = random.randint(0,10)
    def paint(self):
        #利用for循环画动态图片
        canvas.blit(self.img,(self.x,self.y))     
    def step(self):
        #设置移动的时间间隔
        self.y -=self.a
    #给气球设置hit方法
    def hit(self,c):
        return self.x + self.width> c.x > self.x - c.width and\
                self.y + self.height> c.y > self.y - c.height 
#碰撞检测方法
def checkHit():
    #气球与箭碰撞
    for enemy in Game.enemies:
        #如果气球的y坐标小于多少就生命变成0
        if enemy.y<=100:
            enemy.life = 0
            Game.score -=enemy.score   
        for b in Game.bullt:
            if enemy.hit(b):
                #如果碰撞生命为0
                enemy.life = 0
                b.life = 0
                #分值增加
#                 Game.score += 1
                Game.score += enemy.score
            if b.x>900:
                b.life = 0
            
#删除敌人
def canDelete():
    for enemy in Game.enemies:
        if enemy.life == 0:
            Game.enemies.remove(enemy)
    for b in Game.bullt:
        if b.life == 0:
            Game.bullt.remove(b)
            
#写文字
def fillText(text,position):
    my_font = pygame.font.SysFont("微软雅黑", 40)
    newText = my_font.render(text,True,(255,255,255))
    canvas.blit(newText,position)        
#添加敌人
def enemymake(): 
    x1 = random.randint(70,940)
    #生成随机的气球下标
    if not isActionTime(Game.lastTime,Game.interval):
        return
    Game.lastTime = time.time()
    qa = random.randint(0,3)
    Game.enemies.append(Enemy(x1,600,Game.qball[qa]))        

#变量类  
class Game():
    hero = Hero(10,500,s2)
    #修改：添加第二个状态
    state = ["RUN"]
    bullt = []
    enemies = []
    #气球图片列表
    qball = [q1,q2,q3,q4]
    #产生敌飞机的时间间隔
    lastTime = 0
    interval = 0.3
    #分数
    score = 0
def contrl():
    if Game.state[0] == "RUN":
        enemymake()
        Game.hero.paint()
    #修改：在控制流程函数里"RUN"状态中 添加for循环圈 遍历子弹调用函数
        for b in Game.bullt:
            b.paint() 
            b.step()
    #敌人
        for enemy in Game.enemies:
            enemy.paint()
            enemy.step()
        #写分数
        fillText('SCORE:'+str(Game.score),(800,4))
        checkHit()
        canDelete()

        
while True:
    canvas.blit(bg,(0,0))
    
    contrl()
     
    pygame.display.update()
    handleEvent()
 
 












  

