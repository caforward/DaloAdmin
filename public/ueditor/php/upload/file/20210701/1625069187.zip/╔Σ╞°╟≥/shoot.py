#设置画布加载图片
import pygame
from pygame.locals import *
import time
import random
import sys
#初始化pygame环境
pygame.init()
#设置画布
canvas = pygame.display.set_mode((990,600))
canvas.fill((255,255,255))
pygame.display.set_caption("射击")
#加载图片
bg = pygame.image.load("images/蓝色背景.png")
s1 = pygame.image.load("images/s1.png")
s2 = pygame.image.load("images/s2.png")
s3 = pygame.image.load("images/s3.png")

#事件
def handleEvent():
    for event in pygame.event.get():
        if event.type == QUIT :
            pygame.quit() 
            sys.exit()
        if event.type == MOUSEMOTION: #鼠标控制英雄
            if Game.state[0]=="RUN":
                Game.hero.y = event.pos[1] - Game.hero.height/2
        if event.type == KEYDOWN and event.key == K_SPACE:  #按下空格
            if Game.hero.img == s2:   #s2切换s1
                Game.hero.img = s1
                #修改：调用shoot方法
                Game.hero.shoot()
        if event.type == KEYUP and event.key == K_SPACE:#抬起空格
            if Game.hero.img == s1:   #s1切换s2
                Game.hero.img = s2 
                Game.state1 = 0
#hero类
class Hero():
    def __init__(self,x,y,img):
        self.width=60        
        self.height=59
        self.x=x
        self.y=y
        self.img=img
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
    def shoot(self):
        #修改  ：把x，y换成参数换了
        Game.bullt.append(Bullt(56,self.y+25,s3))
#子弹类
class Bullt():
    def __init__(self,x,y,img):
        self.width=60        
        self.height=59
        self.x=x
        self.y=y
        self.img=img
    def paint(self):
        canvas.blit(self.img,(self.x,self.y))
    def step(self):
        self.x += 5    
#变量类  
class Game():
    hero = Hero(10,500,s2)
    #修改：添加第二个状态
    state = ["RUN"]
    bullt = []
def contrl():
    if Game.state[0] == "RUN":
        Game.hero.paint()
    #修改：在控制流程函数里"RUN"状态中 添加for循环圈 遍历子弹调用函数
        for b in Game.bullt:
            b.paint() 
            b.step()  
while True:
    canvas.blit(bg,(0,0))
    contrl()
    pygame.display.update()
    handleEvent()




