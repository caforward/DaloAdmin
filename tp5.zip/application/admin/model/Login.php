<?php
namespace app\admin\model;
use think\Model;
class Login extends Model{
	
}