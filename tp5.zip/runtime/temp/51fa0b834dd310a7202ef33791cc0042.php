<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:73:"D:\phpStudy\WWW\tp5\public/../application/index\view\article\article.html";i:1625076749;s:61:"D:\phpStudy\WWW\tp5\application\index\view\common\header.html";i:1625076833;s:61:"D:\phpStudy\WWW\tp5\application\index\view\common\footer.html";i:1625076688;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
<title>老王个人博客 — 一个站在java开发之路上的草根程序员个人博客网站</title>
<meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta name="keywords" content="个人博客,王风宇个人博客,个人博客系统,老王博客,王风宇">
<meta name="description" content="Lao王博客系统，一个站在java开发之路上的草根程序员个人博客网站。">
<LINK rel="Bookmark" href="favicon.ico" >
<LINK rel="Shortcut Icon" href="favicon.ico" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/staticRes/js/html5shiv.js"></script>
<script type="text/javascript" src="/staticRes/js/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/Hui-iconfont/1.0.8/iconfont.min.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/css/common.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/pifu/pifu.css" />
<!--[if lt IE 9]>
<link href="/staticRes/lib/h-ui/css/H-ui.ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } function showSide(){$('.navbar-nav').toggle();}</script>
</head>
<body>
<header class="navbar-wrapper">
    <div class="navbar navbar-fixed-top">
        <div class="container cl">
            <a class="navbar-logo hidden-xs" href="/">
                <img class="logo" src="https://gz.dqxx.com/wp-content/uploads/2021/06/cropped-dqxx-1-1-1.png" alt="Lao王博客" />
            </a>
            <a class="logo navbar-logo-m visible-xs" href="/">德强高中作业网</a>
            <a aria-hidden="false" class="nav-toggle Hui-iconfont visible-xs" href="javascript:void(0);" onclick="showSide();">&#xe667;</a>
            <nav class="nav navbar-nav nav-collapse w_menu" role="navigation">
                <ul class="cl">
                    <!-- 首页栏目循环cate -->
                    <li class="active"> <a href="/" data-hover="首页">首页</a> </li>
                    <?php if(is_array($cateres) || $cateres instanceof \think\Collection || $cateres instanceof \think\Paginator): $i = 0; $__LIST__ = $cateres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <li> <a href="<?php echo url('cate/index',array('cateid'=>$vo['id'])); ?>" data-hover="<?php echo $vo['catename']; ?>"><?php echo $vo['catename']; ?></a> </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </nav>
            <!-- <nav class="navbar-nav navbar-userbar hidden-xs hidden-sm " style="top: 0;">
                <ul class="cl">
                    <li class="userInfo dropDown dropDown_hover">
                            <a href="javascript:;" ><img class="avatar radius" src="img/40.jpg" alt="丶似浅 "></a>
                            <ul class="dropDown-menu menu radius box-shadow">
                                <li><a href="/app/loginOut">退出</a></li>
                            </ul>
                            <a href="/app/qq" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" ><img class="avatar size-S" src="img/qq.jpg" title="登入">登入</a>
                    </li>
                </ul>
            </nav> -->
        </div>
    </div>
</header>
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/Hui-iconfont/1.0.8/iconfont.min.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/css/common.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/pifu/pifu.css" />
<link rel="stylesheet" type="text/css" href="http://www.tp5.com/static/index/plugin/wangEditor/css/wangEditor.min.css">

<!--导航条-->
<nav class="breadcrumb">
  <div class="container"> <i class="Hui-iconfont">&#xe67f;</i> <a href="index.html" class="c-primary">首页</a> <span class="c-gray en">&gt;</span>  <span class="c-gray"><?php echo $articleres['cateid']; ?></span> <span class="c-gray en">&gt;</span>  <span class="c-gray"><?php echo $articleres['title']; ?></span></div>
</nav>

<section class="container pt-20">
    
    <div class="row w_main_row">
                
                
                <div class="col-lg-9 col-md-9 w_main_left">
                    <div class="panel panel-default  mb-20">
                        <div class="panel-body pt-10 pb-10">
                            <h2 class="c_titile"><?php echo $articleres['title']; ?></h2>
                            <p class="box_c"><span class="d_time">发布时间：<?php echo date("Y-m-d",$articleres['time']); ?></span><span>编辑：<a href="#"><?php echo $articleres['author']; ?></a></span><span>阅读（<?php echo $articleres['click']; ?>）</span></p>
                            <ul class="infos">
                                <?php echo $articleres['content']; ?>
                                <p>&nbsp;</p><p align="center" class="pageLink"></p>
                                
                            </ul>
                                                            
                            <div class="keybq">
                                <p><span>关键字</span>：<a class="label label-default"><?php echo $articleres['keywords']; ?></a></p>    
                            </div>
                            
                            
                            
                            <div class="nextinfo">
                                <p class="last">上一篇：<a href="#">免费收录网站搜索引擎登录口大全</a></p>
                                <p class="next">下一篇：<a href="#">javascript显示年月日时间代码</a></p>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <!--热门推荐-->
    <div class="bg-fff box-shadow radius mb-20">
            <div class="tab-category">
                <a href=""><strong>热门推荐</strong></a>
            </div>
            <div class="tab-category-item">
                <ul class="index_recd">
                    <li>
                        <a href="#">阻止a标签href默认跳转事件</a>
                        <p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
                    </li>
                    <li >
                        <a href="#">PHP面试题汇总</a>
                        <p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
                    </li>
                    <li >
                        <a href="#">阻止a标签href默认跳转事件</a>
                        <p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
                    </li>
                    <li >
                        <a href="#">阻止a标签href默认跳转事件</a>
                        <p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
                    </li>
                    <li >
                        <a href="#">PHP面试题汇总</a>
                        <p class="hits"><i class="Hui-iconfont" title="点击量">&#xe622;</i> 276 </p>
                    </li>
                </ul>
            </div>
        </div>
                        
                    <!--图片-->
      <!--   <div class="bg-fff box-shadow radius mb-20">
            <div class="tab-category">
                <a href=""><strong>扫我关注</strong></a>
            </div>
            <div class="tab-category-item">
                <img data-original="temp/gg.jpg" class="img-responsive lazyload" alt="响应式图片">
            </div>
        </div> -->
                    
                </div>
            </div>
    
</section>
<footer class="footer mt-20">
    <div class="container-fluid" id="foot">
        <p>Copyright &copy; 2016-2021 www.dqxx.com <br>
            <a href="#" target="_blank">黑ICP备12345678号</a>  开发者：<a href="http://www.cf0w.com" target="_blank">哈尔滨德强学校高中部</a><br>
        </p>
    </div>
</footer>
<script type="text/javascript" src="plugin/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="plugin/layer/3.0/layer.js"></script>
<script type="text/javascript" src="plugin/h-ui/js/H-ui.min.js"></script>
<script type="text/javascript" src="plugin/pifu/pifu.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script> $(function(){ $(window).on("scroll",backToTopFun); backToTopFun(); }); </script>
<script type="text/javascript" src="plugin/wangEditor/js/wangEditor.min.js"></script>
<script type="text/javascript">
    $(function () {
            $("img.lazyload").lazyload({failurelimit : 3});
        
        wangEditor.config.printLog = false;
        var editor1 = new wangEditor('textarea1');
        editor1.config.menus = ['insertcode', 'quote', 'bold', '|', 'img', 'emotion', '|', 'undo', 'fullscreen'];
        editor1.config.emotions = { 'default': { title: '老王表情', data: 'plugin/wangEditor/emotions1.data'}, 'default2': { title: '老王心情', data: 'plugin/wangEditor/emotions3.data'}, 'default3': { title: '顶一顶', data: 'plugin/wangEditor/emotions2.data'}};
        editor1.create();

        //show reply
        $(".hf").click(function () {
            pId = $(this).attr("name");
            $(this).parents(".commentList").find(".cancelReply").trigger("click");
            $(this).parent(".comment-body").append($(".comment").clone(true));
            $(this).parent(".comment-body").find(".comment").removeClass("hidden");
            $(this).hide();
        });
        //cancel reply
        $(".cancelReply").on('click',function () {
            $(this).parents(".comment-body").find(".hf").show();
            $(this).parents(".comment-body").find(".comment").remove();
        });
    });

</script>
</body>
</html>
