<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:69:"D:\phpStudy\WWW\tp5\public/../application/admin\view\index\index.html";i:1625164194;s:58:"D:\phpStudy\WWW\tp5\application\admin\view\common\top.html";i:1625162669;s:59:"D:\phpStudy\WWW\tp5\application\admin\view\common\left.html";i:1625071854;}*/ ?>
<!DOCTYPE html>
<html><head>
	    <meta charset="utf-8">
    <title>童老师ThinkPHP交流群：484519446</title>

    <meta name="description" content="Dashboard">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!--Basic Styles-->
    <link href="http://www.tp5.com/static/admin/style/bootstrap.css" rel="stylesheet">
    <link href="http://www.tp5.com/static/admin/style/font-awesome.css" rel="stylesheet">
    <link href="http://www.tp5.com/static/admin/style/weather-icons.css" rel="stylesheet">

    <!--Beyond styles-->
    <link id="beyond-link" href="http://www.tp5.com/static/admin/style/beyond.css" rel="stylesheet" type="text/css">
    <link href="http://www.tp5.com/static/admin/style/demo.css" rel="stylesheet">
    <link href="http://www.tp5.com/static/admin/style/typicons.css" rel="stylesheet">
    <link href="http://www.tp5.com/static/admin/style/animate.css" rel="stylesheet">
    
</head>
<body>
<!-- 头部 -->
    <div class="navbar">
    <div class="navbar-inner">
        <div class="navbar-container">
            <!-- Navbar Barnd -->
            <div class="navbar-header pull-left">
                <a href="#" class="navbar-brand">
                    <small>
                            <img src="http://www.tp5.com/static/admin/images/logo.png" alt="">
                        </small>
                </a>
            </div>
            <!-- /Navbar Barnd -->
            <!-- Sidebar Collapse -->
            <div class="sidebar-collapse" id="sidebar-collapse">
                <i class="collapse-icon fa fa-bars"></i>
            </div>
            <!-- /Sidebar Collapse -->
            <!-- Account Area and Settings -->
            <div class="navbar-header pull-right">
                <div class="navbar-account">
                    <ul class="account-area">
                        <li>

                            <a class="login-area dropdown-toggle" >
                                <section>
                                    <h2><span ><span>TPCfanAdmin框架V1.0.0</span></span></h2>
                                </section>
                            </a>

                            <a class="login-area dropdown-toggle" data-toggle="dropdown">
                                <div class="avatar" title="View your public profile">
                                    <img src="http://www.tp5.com/static/admin/images/adam-jansen.jpg">
                                </div>
                                <section>
                                    <h2><span class="profile"><span><?php echo \think\Request::instance()->session('username'); ?></span></span></h2>
                                </section>
                            </a>
                            <!--Login Area Dropdown-->
                            <ul class="pull-right dropdown-menu dropdown-arrow dropdown-login-area">
                                <li class="username"><a>David Stevenson</a></li>
                                <li class="dropdown-footer">
                                    <a href="<?php echo url('admin/logout'); ?>">
                                            退出登录
                                        </a>
                                </li>
                                <li class="dropdown-footer">
                                    <a href="<?php echo url('admin/exit',array('id'=>\think\Request::instance()->session('uid'))); ?>">
                                            修改密码
                                        </a>
                                </li>
                            </ul>
                            <!--/Login Area Dropdown-->
                        </li>
                        <!-- /Account Area -->
                        <!--Note: notice that setting div must start right after account area list.
                            no space must be between these elements-->
                        <!-- Settings -->
                    </ul>
                </div>
            </div>
            <!-- /Account Area and Settings -->
        </div>
    </div>
</div>

    <!-- /头部 -->

    <!-- /头部 -->
    
    <div class="main-container container-fluid">
        <div class="page-container">
                         <!-- Page Sidebar -->
            <div class="page-sidebar" id="sidebar">
                <!-- Page Sidebar Header-->
                <div class="sidebar-header-wrapper">
                    <input class="searchinput" type="text">
                    <i class="searchicon fa fa-search"></i>
                    <div class="searchhelper">Search Reports, Charts, Emails or Notifications</div>
                </div>
                <!-- /Page Sidebar Header -->
                <!-- Sidebar Menu -->
                <ul class="nav sidebar-menu">
                    <!--Dashboard-->
                     <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-file-text"></i>
                            <span class="menu-text">文章管理</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Article/lst'); ?>">
                                    <span class="menu-text">
                                        文章列表                                    </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li> 

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-file-text"></i>
                            <span class="menu-text">栏目管理</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('Cate/lst'); ?>">
                                    <span class="menu-text">
                                        栏目列表                              </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li> 

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-user"></i>
                            <span class="menu-text">友情链接</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('links/lst'); ?>">
                                    <span class="menu-text">
                                        链接列表                                 </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li>

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-user"></i>
                            <span class="menu-text">管理员表</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="<?php echo url('admin/lst'); ?>">
                                    <span class="menu-text">
                                        管理列表                                    </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li> 

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-file-text"></i>
                            <span class="menu-text">评论中心(待开发)</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="/admin/document/index.html">
                                    <span class="menu-text">
                                        所有评论                                    </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li> 

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-file-text"></i>
                            <span class="menu-text">综合管理(待开发)</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="/admin/document/index.html">
                                    <span class="menu-text">
                                        标签中心                                    </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li> 
                    
                    


                                


                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-gear"></i>
                            <span class="menu-text">系统管理(待开发)</span>
                            <i class="menu-expand"></i>
                        </a>
                        <ul class="submenu">
                            <li>
                                <a href="/admin/document/index.html">
                                    <span class="menu-text">
                                        系统参数                                   </span>
                                    <i class="menu-expand"></i>
                                </a>
                            </li>
                        </ul>                            
                    </li>                        
                    
                                           
                    
                </ul>
                <!-- /Sidebar Menu -->
            </div>
            <!-- /Page Sidebar -->
            <!-- Page Content -->
            <div class="page-content">
                <!-- Page Breadcrumb -->
                <div class="page-breadcrumbs">
                    <ul class="breadcrumb">
                                        <li class="active">控制面板</li>
                                        </ul>
                </div>
                <!-- /Page Breadcrumb -->

                <!-- Page Body -->
                <div class="page-body">
                <div class="col-lg-4 col-sm-6 col-xs-12" style="float: left;">
                                    <div class="databox databox-xlg databox-halved radius-bordered databox-shadowed databox-vertical">
                                        <div class="databox-top bg-white padding-10">
                                            <div class="col-lg-4 col-sm-4 col-xs-4">
                                                <img src="http://www.tp5.com/static/admin//images/adam-jansen.jpg" style="width:75px; height:75px;" class="image-circular bordered-3 bordered-palegreen">
                                            </div>
                                            <div class="col-lg-8 col-sm-8 col-xs-8 text-align-left padding-10">
                                                <span class="databox-header carbon no-margin"><?php echo \think\Request::instance()->session('username'); ?></span>
                                                <span class="databox-text lightcarbon no-margin">欢迎访问德强作业网后台系统！ </span>
                                            </div>
                                        </div>
                                        <div class="databox-bottom bg-white no-padding">
                                            <div class="databox-row row-12">
                                                <div class="databox-row row-6 no-padding">
                                                    <div class="databox-cell cell-4 no-padding text-align-center bordered-right bordered-platinum">
                                                        <span class="databox-text sonic-silver  no-margin">Posts</span>
                                                        <span class="databox-number lightcarbon no-margin">510</span>
                                                    </div>
                                                    <div class="databox-cell cell-4 no-padding text-align-center bordered-right bordered-platinum">
                                                        <span class="databox-text sonic-silver no-margin">Followers</span>
                                                        <span class="databox-number lightcarbon no-margin">908</span>
                                                    </div>
                                                    <div class="databox-cell cell-4 no-padding text-align-center">
                                                        <span class="databox-text sonic-silver no-margin">Following</span>
                                                        <span class="databox-number lightcarbon no-margin">286</span>
                                                    </div>
                                                </div>
                                                <div class="databox-row row-6 padding-10">
                                                    <button class="btn btn-palegreen btn-sm pull-right">FOLLOW</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="well with-header with-footer" style="float: left;">
                                <div class="header bordered-blue">Block Buttons</div>
                                <div class="clearfix">
                                    <a href="#" class="btn btn-yellow btn-block shiny">Link</a>
                                    <button class="btn btn-warning btn-block">Button</button>
                                    <input type="button" class="btn btn-darkorange btn-block" value="Input">
                                    <input type="submit" class="btn btn-danger btn-block" value="Submit">
                                </div>
                                <div class="footer"><code>.btn .btn-block</code></div>
                            </div>

				
                </div>
                

                </div>
                <!-- /Page Body -->
            </div>
            <!-- /Page Content -->
		</div>	
	</div>

	    <!--Basic Scripts-->
    <script src="http://www.tp5.com/static/admin/style/jquery_002.js"></script>
    <script src="http://www.tp5.com/static/admin/style/bootstrap.js"></script>
    <script src="http://www.tp5.com/static/admin/style/jquery.js"></script>
    <!--Beyond Scripts-->
    <script src="http://www.tp5.com/static/admin/style/beyond.js"></script>
    


</body></html>